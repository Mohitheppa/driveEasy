import React from 'react';
import './Home.css'; // Importing CSS file for styling

function Home() {
  return (
    <div className="home-container">
      <h1 className="blog-name">DriveEase</h1><div className='container bg-white'>
      <p className="intro-text bg-white">At DriveEase, we simplify car rental management for businesses of all sizes. Our intuitive platform offers comprehensive tools to streamline your rental operations, from booking and fleet management to customer support and analytics. With DriveEase, managing your car rental service has never been easier. Join us to enhance your efficiency, boost your customer satisfaction, and drive your business forward with ease.</p></div>
    </div>
  );
}

export default Home;

