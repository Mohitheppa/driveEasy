const exp=require('express')
const commonApp=exp.Router()




module.exports=commonApp;